/*****************************************************************************
*
*	File Name:  rtc.c                                         
*                                                                  
*	Content:    provides real_time_clock function for M16C.
*               Modified for M16C/10 MCU                   
*                                                                  
*	Copyright (c) 2001 Mitsubishi Electric & Electronics USA, Inc.                  
*	All rights reserved
*
*	Mitsubishi Electric & Electronics USA does not guarantee the performance or 
*	use of this source-code.  The intended use of provided source-code is the 
*	sole responsible of the user.  The files have been successfully compiled 
*	using Mitsubishi's NC30 compiler.  Before using this software review the 
*   source and make any necessary changes to support your hardware and application.
*                                                               
*=============================================================================
*	$Log: rtc.c,v $
*	Revision 1.2  2002-06-07 14:00:17-04  bembry
*	Fixed flicker problem.  Chang Temp conversion equation fixes problem at "0" crossover point.
*
*===========================================================================*/

#include "delayTimer.h"
#include "10sk.h"
void init_Timer(void);
void wait_ticks(int tickCount);

#pragma	INTERRUPT delay_ticker  //rtc_timer
void delay_ticker(void);

int c_ticks;
// long int total_ticks;
// int fifty_ticks;

// Code ------------------------------------------------------------------------
/*****************************************************************************
Name:         init_Timer
Parameters:   none                  
Returns:      none  
Description:  Intializes Timer   

*****************************************************************************/
void init_Timer(void)
{
	// fifty_ticks=49;
	// total_ticks=0;
    tymod0 = 0;      // Set Timer Y timer mode
	tyck0 = 0;     //divide by 8 = 500 nano seconds long period
    tyck1 = 1;
	tywc = 0;
    prey = 20;     // load Y prescaller with 20 = 20 x 500ns= 10 micro seconds
	typr = 2;		//load Y primary with 2 = 2 x 10 micro secs = 20 microseconds
	DISABLE_INTS
	tyic = 0x03;	// Timer Y interrupt request control register.   
	ENABLE_INTS 

}
/*****************************************************************************
Name:      wait_ticks  waits a number of ticks which equal 20 micro seconds or 1/50 millisecond
Parameters:    none                   
Returns:       none 
Description:   Decrements c_ticks for a count down    

*****************************************************************************/
void wait_ticks(int tickCount){
	tys = 1;		// enable timer X
	c_ticks=tickCount;
	while(c_ticks);
	tys = 0;		// enable timer X
}

/*****************************************************************************
Name:      INTERRUPT HANDLER, rtc_ticker.  
Parameters:    none                   
Returns:       none 
Description:   Decrements c_ticks for a count down    

*****************************************************************************/
void delay_ticker(void)
{
	if(c_ticks)
		c_ticks--;
	// if(fifty_ticks){
		// fifty_ticks--;
	// }
	// else{
		// total_ticks++;
		// fifty_ticks=49;
	// }
}

/*****************************************************************************
Name:      tick_count 
Parameters:    none                   
Returns:       number of milliseconds since program execution
Description:   keep track of time in millisecons

*****************************************************************************/
int tick_count(void)
{
	return c_ticks;
}