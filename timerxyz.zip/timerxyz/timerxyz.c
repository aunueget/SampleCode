/*****************************************************************************
*
*	File Name: timerxyz.c                                    
*                                                                  
*	Content: Example program using Timers X, Y and Z in "Timer Mode"  on the
*            M16C/10 (M3010X) MCU. This program is written for the 'USING 
*            M16C/10 TIMERS X, Y, Z IN TIMER MODE' application note. For
*            demonstration on the MSV30102 Starter Kit. Timer X flashes 
*            the green LED at 1 Hz, Timer Y flashes the amber LED at twice
*            this rate, and Timer Z flashes the red LED at twice again.
*            
*
*       Compiled with NC30 ver. 3.20.00.
*
*       All timing based on 16 Mhz Xtal
* 
*      Copyright,2002 MITSUBISHI ELECTRIC CORPORATION       
*      AND MITSUBISHI SEMICONDUCTOR SYSTEM CORPORATION  
*      and Mitsubishi Electric and Electronics USA                
*
*  
*	THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS,   
*	IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF    
*	MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
*	MITSUBISHI ELECTRIC AND ELECTRONICS USA, INC. AND MITSUBISHI ELECTRIC 	     
*	CORPORATION RESERVE THE RIGHT, WITHOUT NOTICE, TO MAKE CHANGES TO THIS      
*	SOFTWARE. NEITHER MITSUBISHI ELECTRIC AND ELECTRONICS USA, INC. NOR 	    
*   MITSUBISHI ELECTRIC CORPORATION SHALL, IN ANY CIRCUMSTANCES, BE LIABLE 	    
*	FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER 
*	ARISING OUT OF THE USE OR APPLICATION OF THIS SOFTWARE. 		   	            
*=============================================================================
*	$Log: timerxyz.c,v $
*	Revision 1.1  2002-06-06 16:46:34-04  bembry
*	Initial revision
*
*===========================================================================*/

#include "sfr10.h"


#define  CONFIG_TMR_X 0x08  /* 00001000 value to load into timer X mode register
                               ||||||||_  TXMOD0,TXMOD1:TIMER MODE SELECTED
                               ||||||____ R0EDG:        DON'T CARE   
                               |||||_____ TXS:          START COUNTING
                               ||||______ TX0CNT:       LEAVE PIN AS GENERAL I/O
                               |||_______ TXMOD2:       SET TO 0 IN TIMER MODE     
                               ||________ N/A:          SET TO 0, ALL MODES  */

#define  CONFIG_TMR_YZ 0x88 /* 10001000 value to load into timer YZ mode register
                               ||||||||_  TYMOD0:       TIMER MODE SELECTED
                               |||||||__  N/A:          SET TO 0, ALL MODES 
                               ||||||____ TYWC:         WRITE TIMER & RELOAD REG   
                               |||||_____ TYS:          START COUNTING
                               ||||______ TZMOD0,TZMOD1:TIMER MODE SELECTED
                               |||_______ TZWC:         WRITE TIMER & RELOAD REG    
                               ||________ TZS:          START COUNTING */


#define  SRC_SEL   0x15   /* 00010101 value to load into timer count source register
                             ||||||||_  TXCLK0,TXCLK1: SELECT F DIVIDED BY 8
                             ||||||____ TYCLK0,TYCLK1: SELECT F DIVIDED BY 8 
                             ||||______ TZCLK0,TZCLK1: SELECT F DIVIDED BY 8
                             ||________ T1CLK0,T1CLK1: FOR TIMER 1, NOT USED */
                               
                             
#define  grnLED  p3_2       // green LED is connected to p3.2 on the MSV30102 board
#define  redLED  p3_0       // red LED is connected to p3.0 on the MSV30102 board
#define  amberLED  p3_1     // amber LED is connected to p3.1 on the MSV30102 board

#define  CNTR_IPL 0x03     // Timer  priority interrupt level

int time_cnty,time_cntx,time_cntz;

int count;               //Global count value, incremented every second by Timer X



//prototypes
 void init(void);
 void main (void);
#pragma INTERRUPT /B TimerxInt // the /B option speeds processing, see NC30 manual
 void TimerxInt(void);
#pragma INTERRUPT /B TimeryInt 
 void TimeryInt(void);
#pragma INTERRUPT /B TimerzInt 
 void TimerzInt(void);


/*****************************************************************************
Name:    main()       
Parameters: none                     
Returns:  nothing      
Description: initializes variables and LED port. Then does nothing but
wait for TX interrupts.     
**************************************************************************** */

void main (void)
{ 
  time_cntx = 0;  
  time_cnty = 0; 
  time_cntz = 0; 
  count = 0;

  init();
  while (1);      //LED flashing is interrupt driven
}


/*****************************************************************************
Name:     TimerxInt()       
Parameters: none                     
Returns:  nothing      
Description:Timer x Interrupt Service Routine. Interrupts every 5 msec,
            toggles LED every second, and increments global'count'.
**************************************************************************** */

void TimerxInt(void)
{
  
  if ((time_cntx += 5) > (1000))   // = 1 second
  { grnLED ^= 1;                   // toggle LED
    count++;					   // example 1 second "clock" 
    time_cntx = 0;
  }
}


/*****************************************************************************
Name:     TimeryInt()       
Parameters: none                     
Returns:  nothing      
Description:Timer Y Interrupt Service Routine. Interrupts every 2.5 msec,
            toggles LED every half second.  
**************************************************************************** */

void TimeryInt(void)
{
  
  if ((time_cnty += 5) > (1000))   
  { amberLED ^= 1;                   // toggle LED

    time_cnty = 0;
  }
}

/*****************************************************************************
Name:     TimerzInt()       
Parameters: none                     
Returns:  nothing      
Description:Timer Z Interrupt Service Routine. Interrupts every 1.25 msec,
            toggles LED every quarter second.   
**************************************************************************** */

void TimerzInt(void)
{
  
  if ((time_cntz += 5) > (1000))   
  { redLED ^= 1;                   // toggle LED
 
    time_cntz = 0;
  }
}

/*****************************************************************************
Name:  initial()   
Parameters: none                   
Returns:  nothing      
Description: Set up LED ports as outputs and timers for Timer Mode.   
**************************************************************************** */
 void init()
  {
   pd3_0 = 1;      // set ports connected to LED to output.
   pd3_2 = 1;      
   pd3_1 = 1;   
   tcss = SRC_SEL;  //  timers X, Y, Z set to 16MHz divide by 8 
   prex = 99;      // 16MHz xtal, divide by 8, times 10,000 counts-> 5msec interrrupts.
   tx = 99;        // so set prescaler and timer to 100-1
   prey = 99;      // 16MHz xtal, divide by 8, times 5000 counts-> 2.5msec interrrupts.
   typr = 49;        
   prez = 99;      // 16MHz xtal, divide by 8, times 2500 counts-> 1,25msec interrrupts.
   tzpr = 24;        



/* the following procedure for writing an Interrupt Priority Level follows that as
 described in the M16C  data sheets under 'Interrupts' */

   _asm ("   fclr i") ;	     // turn off interrupts before modifying IPL
   txic |= CNTR_IPL;         // use read-modify-write instruction to write IPL
   tyic |= CNTR_IPL;         // set all timers to same priority level
   tzic |= CNTR_IPL;     
   txmr = CONFIG_TMR_X;      // set X for Timer Mode & start counting
   tyzmr = CONFIG_TMR_YZ;    // set Y & Z for Timer Mode & start counting
                             
   _asm ("   fset i");
   
  }
  
 