/*********************************************************************************
*                                                                                
*   File Name:   main.c                                                                
*                                                                                
*   Content:     Contains main loop for demo code                                                                
********************************************************************************** 
*================================================================================*
*   $Log: main.c,v $
*   Revision 1.2  2002-06-07 14:00:18-04  bembry
*   Fixed flicker problem.  Chang Temp conversion equation fixes problem at "0" crossover point.
*================================================================================*/
#include <stdlib.h>
#include <math.h>
#include "10sk.h"		/* SFR register definition */
#include "delayTimer.h" /* delay timer for compass I2C readings*/
#include "compass.h"  //analog compass andrew mcknight
#include "MagAcc.h"		//digital compass revised andrew mcknight

void mode_task(void);
void display_time(char ln);
void modPID_task(void);
void followHeading_task(void);
void toStr(char strNum[9],int value,int menuNum);
int changeVariable(int menuSelected,int changeValue);
int getCompassReading(int avg);
#pragma	INTERRUPT motorToggle //motor toggle
void motorToggle(void);
#pragma	INTERRUPT motorKill //motor kill
void motorKill(void);
void modPID(int error);//pid calculator
int degreeDifferance(int absoluteValue,int current,int desired);//calc error for pid
unsigned char sys_mode;
enum SYSTEM_MODES{RUNNING=0,MENUCHANGE,VALUECHANGE};
int paused, selected_menu;
int allowedTolerance,moveShaft;
int moveCount;
char key;
int motorRunning;
const char menu[5][9] = {
{" KP     "},
{" KI     "},
{" KD     "},
{"TOLERANC"},
{" PAUSED "}};
const char num[15] = {'0','1','2','3','4','5','6','7','8','9',':','F','C',' ','.'};
const char deg_S[8] = {0x08,0x14,0x08,0x00,0x00,0x00,0x00,0x00};
// added object from compass.h
compass heading={0,0,0,"    ","   "};
//pid controller variables
typedef struct{
	int previous_error;  //pid error variable
	int ivar;//pid intral variable
	int dvar;//
	double Kp,Ki,Kd;//pid constants
	double out;
	int runTime;
}pidCon;
pidCon PID;
int kiZeros;
int followTaskTime;
int followTaskPrior;

/*****************************************************************************
Name:		main
Parameters:	None
Returns:	None 
Description: Initializes the system and then responds to user actions.
*****************************************************************************/
void main()
{
	moveCount=0;
	/*** setup input for shaft extended all ,shaft in all ****/
	pd4_2=0;//shaft in all input
	pd4_3=0;// shaft out all input
	/*** setup output move shaft in, move shaft out ****/
	pd4_0=1;//move shaft in
	pd4_1=1;//move shaft out               
	/** setup led ouput ***/
	pd4_4=1;
	motorRunning=0;
	allowedTolerance=0;//degrees + or minus of the heading on start
  //menu prep*******************************************
  paused=1;
  selected_menu=0;
  sys_mode =  RUNNING;
  //end of menu prep**********************************************
    init_BSP();     // Intialize Board Support Package.
    disp_ctrlw(0x78); // write CGRAM address pointer 
    for (key=0; key <8; key++)   // degree symbole is 0x08 hex.  
        disp_dataw(deg_S[key]);  // Write degree symbole to LCD's CGRAM area.       
	init_Timer(); 
     /*** enable electric motor one-shot start interupt.****/   /*** enable 32K clcok for real time clock.****/
    prc0 = 1;       // Enable writes to clock control register.
    cm03 = 1;       // Xcin, Xcout high drive mode  
    cm04 = 1;       // Enable Xcin, Xcout ports 
    cm2 = 0x03;      // Enable OSC STOPPED detection 
    prc0 = 0;       // Disable writes to clock control register. 
	t1ck0 = 1; t1ck1 = 1; // Set Timer 1 count source to 1/32
	pre1 = 2;       // Load prescaler with 1
    t1 = 2;       // load t1 with 4  2 x 5 = 10 :// 32.768 KHz / 32 / 10 = 102.4 times a second = 10 msec
	DISABLE_INTS
	t1ic = 0x06; 	// timer 1 underflow interrut.  (S4). 
	ENABLE_INTS 
	
    /*** enable one-shot motor kill interupt.****/
	tzmod0 = 0;      // Set Timer Z timer mode to programmable wait one-shot
	tzmod1 = 1;		// Set Timer Z timer mode 
	tzck0 = 1;     //divide by 32 = 1 milli second seconds long period
    tzck1 = 1;		//divide by 32 = 1 milli second seconds long period
	tzwc = 1;
    prez = 0;		// load Z prescaller with 0 = 1ms
	tzpr = 1;		//load Z primary with 5 = 5 x 1 milli secs = 5 milliseconds
	tzpum0 = 0;
	//tzpum1 = 0; 
	DISABLE_INTS
	tzic = 0x02;	// Timer Z interrupt request control register.   
	ENABLE_INTS 
	/****   Initialize Digital compass reading **************/
	initMagAcc();
	/****   End of Initialize Digital compass reading **************/
	//init PID variables
	PID.previous_error=0;  //PID error variable
	PID.ivar=0;//PID intral variable
	PID.dvar=0;//
	PID.Kp=50;
	PID.Ki=.60;//.00001;
	PID.Kd=50;
	PID.out=0;
	PID.runTime=0;
	kiZeros=4;
	//end init PID variables
	//intro screen
	display(0,"AUTOHELM");
	display(1," < > OK ");
	
    //addTask(display_task, 30, 1);
	followTaskTime=100;
	followTaskPrior=4;
    addTask(mode_task, 35, 3);
	//addTask(shaftDelayToggle_task,1,2);
    addTask(modPID_task, 100,1);

    Run_RR_Scheduler();
}
/*****************************************************************************
Name:         mode_task  
Parameters:                     
Returns:        
Description:  Process key inputs and changes mode and data.    
*****************************************************************************/
void mode_task(void)
{	
	//KEY_A IS UP//KEY_B IS DOWN//KEY_C IS OK
	int i=0;
	int selected_value=0;
	char tempStr[9]="";
    int testHeading=0;
	key = dequeue_key();
    switch(sys_mode){
		case RUNNING:
			if(paused){
				if(key==KEY_C){
					paused=0;
					set_desired(&heading,getCompassReading(0));
					//init PID variables
					PID.ivar=0;//PID intral variable
					PID.dvar=0;//
					PID.out=0;
					//end init PID variables
					addTask(followHeading_task, followTaskTime, followTaskPrior);
				}
				else if(key==KEY_A||key==KEY_B){
					sys_mode=MENUCHANGE;
					selected_menu=0;
				  	display(0,menu[0]);
					display(1," < > OK ");
				}
				else{
					toStr(tempStr,heading.desired,0);
					display(0,tempStr);
					display(1,menu[4]);//display paused
				}
			}
			else if(key==KEY_A || key == KEY_B || key == KEY_C){
					paused=1;//true
					toStr(tempStr,heading.desired,0);
					display(0,tempStr);
					display(1,menu[4]);//display paused
					p4_1=0;//set move out to off
					p4_0=0;//set move in to off
					DISABLE_INTS
					motorRunning=0;
					ENABLE_INTS
					removeTask(followHeading_task);
			}
		break;
		case MENUCHANGE:
			switch(key){
				case KEY_A:
					selected_menu++;
					display(1," < > OK ");
				break;
				case KEY_B:
					selected_menu--;
					display(1," < > OK ");
				break;
				case KEY_C:
					sys_mode=VALUECHANGE;
					selected_value=changeVariable(selected_menu,0);
					toStr(tempStr,selected_value,selected_menu);
					display(1,tempStr);					
				break;
				
			}
		  if(selected_menu<0)
			selected_menu=3;
		  else if(selected_menu>3)
			selected_menu=0;
		display(0,menu[selected_menu]);
		break;
		case VALUECHANGE:
			switch(key){
				case KEY_A:
					selected_value=changeVariable(selected_menu,-1);
					toStr(tempStr,selected_value,selected_menu);
					display(0,menu[selected_menu]);
					display(1,tempStr);					
				break;
				case KEY_B:
					selected_value=changeVariable(selected_menu,1);
					toStr(tempStr,selected_value,selected_menu);
					display(0,menu[selected_menu]);
					display(1,tempStr);					

				break;
				case KEY_C:
					sys_mode=RUNNING;
					paused=0;
						set_desired(&heading,getCompassReading(0));
						//init PID variables
						PID.ivar=0;//PID intral variable
						PID.dvar=0;//
						PID.out=0;
						//end init PID variables
						addTask(followHeading_task, followTaskTime, followTaskPrior);
				break;
			}
		break;
    }
}

void toStr(char strNum[9],int value,int menuNum){
	strNum[0]=' ';
	strNum[1]=' ';
	if(menuNum==8){
		strNum[2]='>';
	}
	else{
		strNum[2]=' ';
	}
	strNum[3]=(value/100)+48;
	strNum[4]=(((value%100)/10))+48;
	strNum[5]=(value%10)+48;
	if(menuNum!=1 ){
		strNum[6]=0x07;
	}
	else{
		strNum[6]=' ';
	}
	if(menuNum==9){
		strNum[7]='<';
	}
	else{
		strNum[7]=' ';
	}
	strNum[8]='\0';
}
int changeVariable(int menuSelected,int changeValue){
	switch(menuSelected){
		case 0:
			PID.Kp+=(changeValue);//PID.Kp+=(changeValue);
			if(PID.Kp<0)
				PID.Kp=0;
			return PID.Kp;
		break;
		case 1:
			if(changeValue>0){
				PID.Ki+=.01;//=10;
				//kiZeros++;
			}
			else if(changeValue<0){
				PID.Ki -=.01;
				//kiZeros--;
			}
			if(PID.Ki<0){
			//kiZeros<0){
				PID.Ki=0;
				//kiZeros=0;
			}
			return PID.Ki*100;//kiZeros;
		break;
		case 2:
			PID.Kd+=(changeValue);//PID.Kd+=(10*changeValue);
			if(PID.Kd<0)
				PID.Kd=0;
			return PID.Kd;
		break;
		case 3:
			allowedTolerance+=changeValue;
			if(allowedTolerance<0)
				allowedTolerance=0;
			return allowedTolerance;
		break;
	}
	return 0;
}
/*****************************************************************************
Name:           shaftDelayToggle      
Parameters:     none                     
Returns:        none
Description:    this helps create an intermitent shaft movement by waiting the 
					aloted moveDelay time with the shaft moving and then
					spending the same moveDelay time without moving the shaft
*****************************************************************************/
void motorToggle(){
	DISABLE_INTS
	tzpr = (unsigned char) PID.runTime;	
	tzs=1;
	if(!p4_2&&motorRunning<0&&PID.runTime>0){
		p4_1=0;//set move out to off
		p4_0=1;//set move in to on
		if(PID.runTime<9){
			tzos=1;
		}
	}
	else if(!p4_3&&motorRunning>0&&PID.runTime>0){
		p4_0=0;//set move in to off
		p4_1=1;//set move out to on
		if(PID.runTime<9){
			tzos=1;
		}
	}
	else{
		p4_1=0;//set move out to off
		p4_0=0;//set move in to off
	}
	ENABLE_INTS 
}
void motorKill(void){
		p4_1=0;//set move out to off
		p4_0=0;//set move in to off
}
/*****************************************************************************
Name:         AD_sample_task 
Parameters:                     
Returns:        
Description:  calculates the pidOutput

*****************************************************************************/
void modPID_task(void)
{
	if(degreeDifferance(1,heading.current,heading.desired)>allowedTolerance){
		modPID(degreeDifferance(0,heading.desired,heading.current));
	}
}
/*****************************************************************************
Name:        getCompassReading 
Parameters:        none             
Returns:        a newly read compass heading from the digital compass
Description:  returns a newly read compass heading from the digital compass   

*****************************************************************************/
int getCompassReading(int avg){
	double newDigitHeading=get_digital_heading();
	double old_value=heading.current;
	newDigitHeading-=180;//flip the compass to correct digital compass position
    if (newDigitHeading < 0) newDigitHeading += 360;
	if(abs(old_value-newDigitHeading)>180)
		old_value=newDigitHeading+degreeDifferance(1,old_value,newDigitHeading);
	if(avg&&degreeDifferance(1,old_value,newDigitHeading)<20){
		newDigitHeading=((5.0/16.0)*old_value)+(((16.0-5.0)/16.0)*newDigitHeading);
	}
	if(newDigitHeading>360)
		newDigitHeading-=360;
return (int)newDigitHeading;
}
void modPID(int error){
	int dterm=degreeDifferance(0,heading.current,PID.dvar);
	PID.dvar=heading.current;
	PID.ivar = PID.ivar + error;
	if(PID.ivar>100){
		PID.ivar=100;
	}
	if(PID.ivar<(-100)){
		PID.ivar=-100;
	}
	PID.previous_error = error;
	PID.out=((PID.Kp/10.0)*error) + ((PID.Ki/10.0)*PID.ivar) - ((PID.Kd/10.0)*dterm);
	if((int)abs(PID.out)>100){
		DISABLE_INTS
		PID.runTime=11;
		ENABLE_INTS 
	}
	else{
		DISABLE_INTS
		PID.runTime=((abs(PID.out))/100)*9;
		ENABLE_INTS 
	}
}
/* if the absoluteValue is set to 0 then degreeDifferance will have a sign pos or  neg */
int degreeDifferance(int absoluteValue,int current,int desired){
	int compDiff=0;
	int accrossN=0;
	compDiff=abs(current-desired);
	if(compDiff>180){
		compDiff=abs(compDiff-360);
		accrossN=1;
	}
	if(absoluteValue || ((heading.current>heading.desired && accrossN==0) || (accrossN==1 && heading.current<heading.desired))){
		return compDiff;
	}
	else{
		return (-1*compDiff);
	}
}
/**********************************************************************************
Name:		  followHeading
Parameters:
Returns:
Description:  sets the lines to high and low to move the motor in order to follow the heading
**************************************************************************/

void followHeading_task(){
	char temp0Str[9]="\0";
	char temp1Str[9]="\0";
	set_compass(&heading,getCompassReading(1));
	if(degreeDifferance(1,heading.current,heading.desired)>allowedTolerance){
		toStr(temp0Str,heading.current,0);
		display(0,temp0Str);
		if(!p4_2&&PID.out>0){
			if(motorRunning>0){
				DISABLE_INTS
				motorRunning=0;
				p4_1=0;//set move out to off
				ENABLE_INTS 
				tdelay(50);
			}
			DISABLE_INTS
			motorRunning=-1;
			ENABLE_INTS 
			toStr(temp1Str,heading.desired,9);
			display(1,temp1Str);
		}
		if(!p4_3&&PID.out<0){
			if(motorRunning<0){
				DISABLE_INTS
				motorRunning=0;
				p4_0=0;//set move in to off
				ENABLE_INTS 
				tdelay(50);
			}
				DISABLE_INTS
				motorRunning=1;
				ENABLE_INTS
			toStr(temp1Str,heading.desired,8);
			display(1,temp1Str);
		}
	}
	else{
		DISABLE_INTS
		motorRunning=0;
		p4_1=0;//set move out to off
		p4_0=0;//set move in to off
		ENABLE_INTS 		
		tdelay(50);
		toStr(temp0Str,heading.current,0);
		display(0,temp0Str);
	}
	if(p4_2){
		p4_0=0;
		display(1,"SHAFT IN");
	}
	else if(p4_3){
		p4_1=0;
		display(1,"SHAFTOUT");
	}
}
